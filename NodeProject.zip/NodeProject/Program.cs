﻿using System.ComponentModel.Design;
using System.Diagnostics.CodeAnalysis;

namespace NodeProject
{
    internal class Program
    {
        static void Main(string[] args) {
            Menu();
        }
        static public void RunTests() {
            Console.WriteLine("======= LINKED LIST TEST (1-22) =======");

            //SETUP LISTS 
            Node<int> list = new Node<int>(10);
            AddLast(list, 20);
            AddLast(list, 30);

            // #1 NumberOfNodes
            Console.WriteLine($"#1 NumberOfNodes: {NumberOfNodes(list)}");

            // #2 AddFirst
            list = AddFirst(list, 5);
            Console.WriteLine($"#2 AddFirst (5): {list}");

            // #3 AddLast
            list = AddLast(list, 40);
            Console.WriteLine($"#3 AddLast (40): {list}");

            // #4 AddAfter
            Node<int> secondNode = list.GetNext();
            AddAfter(secondNode, 15);
            Console.WriteLine($"#4 AddAfter 10: {list}");

            // #5 DeleteFirst
            list = DeleteFirst(list);
            Console.WriteLine($"#5 DeleteFirst: {list}");

            // #6 DeleteLast
            list = DeleteLast(list);
            Console.WriteLine($"#6 DeleteLast: {list}");

            // #7 DeleteAfter
            DeleteAfter(list);
            Console.WriteLine($"#7 DeleteAfter Head: {list}");

            // #8 ReturnFirst
            Console.WriteLine($"#8 ReturnFirst: {ReturnFirst(list).GetValue()}");

            // #9 ReturnLast
            Console.WriteLine($"#9 ReturnLast: {ReturnLast(list).GetValue()}");

            // #10 ReturnNodeByIndex
            Console.WriteLine($"#10 ReturnNodeByIndex (1): {ReturnNodeByIndex(list, 1).GetValue()}");

            // #11 ContainsNode
            Console.WriteLine($"#11 ContainsNode (20): {ContainsNode(list, 20)}");

            // #12 & #13 IsListCircled & PrintLoopedList
            Node<int> circ = new Node<int>(1);
            AddLast(circ, 2);
            ReturnLast(circ).SetNext(circ);
            Console.WriteLine($"#12 IsListCircled: {IsListCircled(circ)}");
            Console.Write("#13 PrintLoopedList: ");
            PrintLoopedList(circ);

            // --- REFRESH LIST FOR DATA TESTS ---
            Node<int> dataList = new Node<int>(50);
            AddLast(dataList, 10);
            AddLast(dataList, 50);
            AddLast(dataList, 30);

            // #14 DeleteDupes
            Console.WriteLine($"\nBase for Dupes: {dataList}");
            dataList = DeleteDupes(dataList);
            Console.WriteLine($"#14 DeleteDupes: {dataList}");

            // #15 DeleteDupesReturnNewList
            Node<int> dupeSource = new Node<int>(5); AddLast(dupeSource, 5); AddLast(dupeSource, 1);
            Node<int> cleanNew = DeleteDupesReturnNewListV2(dupeSource);
            Console.WriteLine($"#15 DeleteDupes: {cleanNew}");

            // #16 DuplicateList
            Node<int> copy = DuplicateList(list);
            Console.WriteLine($"#16 DuplicateList: {copy}");

            // #17 ReverseList
            Node<int> rev = ReverseList(DuplicateList(list));
            Console.WriteLine($"#17 ReverseList: {rev}");

            // #18 SortList
            Node<int> unsorted = new Node<int>(90); AddLast(unsorted, 10); AddLast(unsorted, 50);
            Console.WriteLine($"#18 SortList (90,10,50): {SortList(unsorted)}");

            // #19 CompareLists
            Console.WriteLine($"#19 CompareLists (Original vs Copy): {CompareLists(list, copy)}");

            // #20 MixLists (with duplicates)
            Node<int> m1 = new Node<int>(1); AddLast(m1, 2);
            Node<int> m2 = new Node<int>(2); AddLast(m2, 3);
            Console.WriteLine($"#20 MixLists: {MixLists(m1, m2)}");

            // #21 MixListsNoDupes
            Console.WriteLine($"#21 MixListsNoDupesV2: {MixListsNoDupesV2(m1, m2)}");

            // #22 MixListsOnlyCommons
            Console.WriteLine($"#22 MixListsOnlyCommons: {MixListsOnlyCommons(m1, m2)}");

            // WORKER TEST

            Console.WriteLine("\n======= PHASE 2: WORKER CLASS TESTS =======");

            Worker alice = new Worker("Alice", 5000);
            Worker bob = new Worker("Bob", 3000);
            Worker aliceDuplicate = new Worker("Alice", 5000);

            Node<Worker> workerList = new Node<Worker>(alice);
            AddLast(workerList, bob);
            AddLast(workerList, aliceDuplicate);

            Console.WriteLine($"Initial Worker List: {workerList}");

            // Sort Workers by Salary (#18)
            workerList = SortList(workerList);
            Console.WriteLine($"Workers Sorted by Salary: {workerList}");

            // Remove Duplicate Workers (#14/15)
            workerList = DeleteDupesReturnNewListV2(workerList);
            Console.WriteLine($"Unique Workers: {workerList}");

            Node<Worker> searchList = new Node<Worker>(new Worker("Alice", 5000));
            Node<Worker> commons = MixListsOnlyCommons(workerList, searchList);
            Console.WriteLine($"Common Workers found: {commons}");


            // STUDENT TEST Q 24 //
            // 1.Courses for Student 1 (Avi)
            Node<Course> aviCourses = new Node<Course>(new Course("CS101", 95));
            AddLast(aviCourses, new Course("Math202", 88));
            AddLast(aviCourses, new Course("English101", 92));

            // 2.Courses for Student 2 (Dana)
            Node<Course> danaCourses = new Node<Course>(new Course("CS101", 100));
            AddLast(danaCourses, new Course("Physics301", 98));

            // 3.Courses for Student 3 (Noam)
            Node<Course> noamCourses = null;

            // 4. Create the Students
            Student s1 = new Student("Avi", aviCourses);
            Student s2 = new Student("Dana", danaCourses);
            Student s3 = new Student("Noam", noamCourses);

            // 5. Create the List of Students (Node<Student>)
            Node<Student> studentList = new Node<Student>(s1);
            AddLast(studentList, s2);
            AddLast(studentList, s3);
            Console.WriteLine("======= STUDENT GRADE REPORT =======");
            PrintAverageGradeForEachStudent(studentList);
            // QUESTION 25 - >
            // --- CLASS 1: ---
            // Student: Liam
            Node<Course> liamCourses = new Node<Course>(new Course("Calc1", 90));
            AddLast(liamCourses, new Course("Physics", 90));
            Student liam = new Student("Liam", liamCourses);
            // Student: Sophia
            Node<Course> sophiaCourses = new Node<Course>(new Course("Calc1", 94));
            AddLast(sophiaCourses, new Course("Physics", 96));
            Student sophia = new Student("Sophia", sophiaCourses);
            Student[] engineeringClass = { liam, sophia };
            // --- CLASS 2 :---
            // Student: Ethan ->
            Node<Course> ethanCourses = new Node<Course>(new Course("Bio101", 100));
            AddLast(ethanCourses, new Course("Chem101", 100));
            Student ethan = new Student("Ethan", ethanCourses);
            // Student: Olivia
            Node<Course> oliviaCourses = new Node<Course>(new Course("Bio101", 82));
            AddLast(oliviaCourses, new Course("Chem101", 80));
            Student olivia = new Student("Olivia", oliviaCourses);
            Student[] biologyClass = { ethan, olivia };
            // school list with the first classroom array
            Node<Student[]> academicYear2026 = new Node<Student[]>(engineeringClass);
            AddLast(academicYear2026, biologyClass);
            Node<Student> topPerformers = ReturnExcellentStudents(academicYear2026);
            Console.WriteLine("\nTop Student per Class:");
            Console.WriteLine(topPerformers);
            Console.WriteLine("====================================");
            //Question 26 - >
            Console.WriteLine($"\n\n\n");
            // --- 1. Create Class A ---
            Student st1 = new Student("Avi", new Node<Course>(new Course("Math", 90)));
            Student st2 = new Student("Dana", new Node<Course>(new Course("Math", 40)));
            Node<Student> classA = new Node<Student>(st1);
            AddLast(classA, st2);
            // --- 2. Create Class B ---
            Node<Course> c3 = new Node<Course>(new Course("Bio", 100));
            AddLast(c3, new Course("Chem", 80));
            AddLast(c3, new Course("Physics", 30));
            Student st3 = new Student("Noam", c3);
            Node<Student> classB = new Node<Student>(st3);
            // --- 3. Create array of Lists ---
            Node<Student>[] schoolArray = new Node<Student>[2];
            schoolArray[0] = classA;
            schoolArray[1] = classB;
            // --- 4. Run the function ---
            Node<Student> graduates = ReturnGraduatingStudents(schoolArray);
            // --- 5. Print results ---
            Console.WriteLine("\nGraduating Students:");
            Console.WriteLine(graduates);

            // Question 27 -> Palindrome Check
            Console.WriteLine("\n\n\n======= PALINDROME TEST (Q27) =======");

            // Test 1: "LEVEL" (Palindrome)
            BinNode<char> l1 = new BinNode<char>('L');
            BinNode<char> e1 = new BinNode<char>('E');
            BinNode<char> v1 = new BinNode<char>('V');
            BinNode<char> e2 = new BinNode<char>('E');
            BinNode<char> l2 = new BinNode<char>('L');

            // Link
            l1.SetRight(e1); e1.SetLeft(l1);
            e1.SetRight(v1); v1.SetLeft(e1);
            v1.SetRight(e2); e2.SetLeft(v1);
            e2.SetRight(l2); l2.SetLeft(e2);

            Console.WriteLine($"Is 'LEVEL' a palindrome? {IsPalindrome(l1)}"); // Expected: True

            // Test 2: "HELLO" (Not Palindrome)
            BinNode<char> h = new BinNode<char>('H');
            BinNode<char> e = new BinNode<char>('E');
            BinNode<char> l = new BinNode<char>('L');
            BinNode<char> l_2 = new BinNode<char>('L');
            BinNode<char> o = new BinNode<char>('O');

            h.SetRight(e); e.SetLeft(h);
            e.SetRight(l); l.SetLeft(e);
            l.SetRight(l_2); l_2.SetLeft(l);
            l_2.SetRight(o); o.SetLeft(l_2);
            Console.WriteLine($"Is 'HELLO' a palindrome? {IsPalindrome(h)}");

            Console.WriteLine("\nALL TESTS COMPLETED. Press any key to close.");
            Console.ReadKey();
        }
        public static int NumberOfNodes<T>(Node<T> head) {
            if (head == null) {
                return 0;
            }
            int counter = 0;
            while (head != null) {
                counter++;
                head = head.GetNext();
            }

            return counter;
        } // Count the length of a list #1
        public static Node<T> AddFirst<T>(Node<T> head, T value) {
            if (head == null) {
                return new Node<T>(value);
            }
            Node<T> newNode = new Node<T>(value);
            newNode.SetNext(head);
            return newNode;
        } // Add a node to the first spot in a list #2
        public static Node<T> AddLast<T>(Node<T> head, T value) {
            Node<T> newNode = new Node<T>(value);

            if (head == null) {
                return newNode;
            }

            Node<T> lastNode = head;
            while (lastNode.HasNext()) {
                lastNode = lastNode.GetNext();
            }
            lastNode.SetNext(newNode);

            return head;
        } // Add a node to the last spot in a list #3
        public static void AddAfter<T>(Node<T> prev, T value) {
            Node<T> newNode = new Node<T>(value);
            newNode.SetNext(prev.GetNext());
            prev.SetNext(newNode);
        } // Add a node after a previous node #4
        public static Node<T> DeleteFirst<T>(Node<T> head) {
            if (head == null) {
                return null;
            }
            return head.GetNext();
        } // Delete the first node #5
        public static Node<T> DeleteLast<T>(Node<T> head) {
            if (head == null || !head.HasNext()) {
                return null;
            }

            Node<T> prevNode = null;
            Node<T> lastNode = head;
            while (lastNode.HasNext()) {
                prevNode = lastNode;
                lastNode = lastNode.GetNext();
            }
            prevNode.SetNext(null);

            return head;
        } // Delete the last node #6
        public static void DeleteAfter<T>(Node<T> prev) {
            if (prev == null || !prev.HasNext())
                return;
            prev.SetNext(prev.GetNext().GetNext());
        }// Delete after a specific node #7
        public static Node<T> ReturnFirst<T>(Node<T> head) {
            return head;
        } // Return the first node #8
        public static Node<T> ReturnLast<T>(Node<T> head) {
            if (head == null) {
                return null;
            }
            while (head.HasNext()) {
                head = head.GetNext();
            }
            return head;
        } // Return the last node #9
        public static Node<T> ReturnNodeByIndex<T>(Node<T> head, int index) {
            if (head == null || index < 0) {
                return null;
            }
            int counter = 0;
            while (head != null) {
                if (counter == index) {
                    return head;
                }
                counter++;
                head = head.GetNext();
            }
            return null;
        } // Return a node by index #10
        public static bool ContainsNode<T>(Node<T> head, T value) {
            if (head == null) {
                return false;
            }
            while (head != null) {
                if (head.GetValue() != null && head.GetValue().Equals(value))
                    return true;
                head = head.GetNext();
            }
            return false;
        } // Check if a list contains a node by value #11
        public static bool IsListCircled<T>(Node<T> head) {
            if (head == null)
                return false;
            Node<T> temp = head.GetNext();
            while (temp != null) {
                temp = temp.GetNext();
                if (temp == head) return true;
            }
            return false;
        } // Check if a list is circled #12
        public static void PrintList<T>(Node<T> head) {
            while (head != null) {
                if (!head.HasNext()) {
                    Console.WriteLine(head.GetValue());
                    return;
                }
                Console.Write($"{head.GetValue()}, ");
                head = head.GetNext();
            }
        } // Print a list with , #(13)
        public static void PrintListV2<T>(Node<T> head) {
            Console.WriteLine(head);
        } // Print a list using the Node class ToString() #(13)
        public static void PrintLoopedList<T>(Node<T> head) {
            if (head == null)
                return;
            Node<T> temp = head;
            do {
                if (temp.GetNext() == head || temp.GetNext() == null)
                    Console.WriteLine(temp.GetValue());
                else
                    Console.Write(temp.GetValue() + ", ");
                temp = temp.GetNext();
            }
            while (temp != head);

            Console.WriteLine();
        } // Print a circeled list #13
        public static Node<T> DeleteNodeByIndex<T>(Node<T> head, int index) {
            Node<T> temp = head;
            if (head == null || (index == 0 && !head.HasNext()))
                return null;

            if (index == 0)
                return head.GetNext();

            int counter = 0;
            while (temp != null) {
                if (counter + 1 == index) {
                    if (temp.GetNext() != null) {  // Check if a user asked to delete an index that doesnt exist
                        temp.SetNext(temp.GetNext().GetNext());
                    }
                    break;
                }
                temp = temp.GetNext();
                counter++;
            }
            return head;
        } // פונקציה שיצרתי כי חשבתי שהיא תעזור לי בהמשך
        public static Node<T> DeleteDupes<T>(Node<T> head) {
            if (head == null)
                return null;
            Node<T> current = head;
            while (current != null) {
                Node<T> runner = current;

                while (runner.GetNext() != null) {
                    if (runner.GetNext().GetValue().Equals(current.GetValue()))
                        runner.SetNext(runner.GetNext().GetNext());
                    else
                        runner = runner.GetNext();
                }
                current = current.GetNext();
            }
            return head;
        } // Delete duplicates from a list #14
        public static Node<T> DeleteDupesReturnNewList<T>(Node<T> head) {
            if (head == null)
                return null;
            if (!head.HasNext())
                return new Node<T>(head.GetValue());
            Node<T> newListHead = new Node<T>(head.GetValue());
            head = head.GetNext();
            while (head != null) {
                AddLast(newListHead, head.GetValue());
                head = head.GetNext();
            }
            return DeleteDupes(newListHead);
        } // Delete duplicates but return a new list #15
        public static Node<T> DeleteDupesReturnNewListV2<T>(Node<T> head) {
            if (head == null)
                return null;
            Node<T> newListHead = new Node<T>(head.GetValue());
            Node<T> current = head.GetNext();
            while (current != null) {
                if (!ContainsNode(newListHead, current.GetValue())) {
                    AddLast(newListHead, current.GetValue());
                }
                current = current.GetNext();
            }
            return newListHead;
        } // Delete duplicates and return a new list but without using DeleteDupes function#15
        public static Node<T> DuplicateList<T>(Node<T> head) {
            if (head == null)
                return null;
            Node<T> newDuplicatedList = new Node<T>(head.GetValue());
            head = head.GetNext();
            while (head != null) {
                AddLast(newDuplicatedList, head.GetValue());
                head = head.GetNext();
            }
            return newDuplicatedList;
        } // Return a duplicated list #16
        public static Node<T> ReverseList<T>(Node<T> head) {
            if (head == null)
                return null;
            if (!head.HasNext())
                return head;
            Node<T> prev = null;
            Node<T> current = head;
            Node<T> next = null;
            while (current != null) {
                next = current.GetNext();
                current.SetNext(prev);
                prev = current;
                current = next;
            }
            return prev;
        } // Reverse a list without making a new one #17 (hardest one yet)
        public static Node<T> SortList<T>(Node<T> head) where T : IComparable<T> {
            if (head == null || !head.HasNext())
                return head;
            int count = NumberOfNodes(head);
            for (int i = 0; i < count; i++) {
                bool swapped = false;
                Node<T> current = head;
                while (current != null && current.GetNext() != null) {
                    if (current.GetValue().CompareTo(current.GetNext().GetValue()) > 0) {
                        T temp = current.GetValue();
                        current.SetValue(current.GetNext().GetValue());
                        current.GetNext().SetValue(temp);
                        swapped = true;
                    } // > 0 ->current is bigger , < 0 -> current is smaller , = 0 they're equals
                    current = current.GetNext();
                }
                if (!swapped) // Stops the loop if the list is already sorted
                    break;
            }
            return head;
        } // Sort a list using bubblesort and compareTo #18
        public static bool CompareLists<T>(Node<T> head1, Node<T> head2) {
            while (head1 != null && head2 != null) {
                if (!head1.GetValue().Equals(head2.GetValue())) {
                    return false;
                }
                head1 = head1.GetNext();
                head2 = head2.GetNext();
            }
            return head1 == null && head2 == null; // Return true if both are null, return false if only one is null
        } // Compares 2 lists length and values #19
        public static Node<T> MixLists<T>(Node<T> head1, Node<T> head2) {
            if (head1 == null && head2 == null)
                return null;
            if (head1 == null && head2 != null)
                return DuplicateList<T>(head2);
            if (head2 == null && head1 != null)
                return DuplicateList<T>(head1);
            Node<T> newList = new Node<T>(head1.GetValue());
            head1 = head1.GetNext();
            while (head1 != null) {
                AddLast<T>(newList, head1.GetValue());
                head1 = head1.GetNext();
            }
            while (head2 != null) {
                AddLast(newList, head2.GetValue());
                head2 = head2.GetNext();
            }
            return newList;
        } // Return a mixed lists of 2 lists with reaccuring values #20
        public static Node<T> MixListsNoDupes<T>(Node<T> head1, Node<T> head2) {
            return DeleteDupesReturnNewList(MixLists(head1, head2));
        } // Return a mixed list of 2 lists without reaccuring values, cleaner #21
        public static Node<T> MixListsNoDupesV2<T>(Node<T> head1, Node<T> head2) {
            if (head1 == null && head2 == null) return null;
            if (head1 == null) return DeleteDupesReturnNewList(head2);
            if (head2 == null) return DeleteDupesReturnNewList(head1);
            Node<T> newList = new Node<T>(head1.GetValue());
            head1 = head1.GetNext();
            while (head1 != null) {
                if (!ContainsNode<T>(newList, head1.GetValue()))
                    AddLast<T>(newList, head1.GetValue());
                head1 = head1.GetNext();
            }
            while (head2 != null) {
                if (!ContainsNode<T>(newList, head2.GetValue()))
                    AddLast<T>(newList, head2.GetValue());
                head2 = head2.GetNext();
            }
            return newList;
        } // Return a mixed list of 2 lists without reaccuring values, more efficiently #21
        public static Node<T> MixListsOnlyCommons<T>(Node<T> head1, Node<T> head2) {
            if (head1 == null || head2 == null) return null;
            bool found = false;
            Node<T> newList = null;
            while (head1 != null) {
                if (ContainsNode<T>(head2, head1.GetValue())) {
                    if (found == false) {
                        newList = new Node<T>(head1.GetValue());
                        found = true;
                    }
                    else
                        AddLast(newList, head1.GetValue());
                }
                head1 = head1.GetNext();
            }
            return DeleteDupesReturnNewList(newList);
        } // Return a mixed list of 2 lists with only commong values #22
        public static void PrintAverageGradeForEachStudent(Node<Student> listHead) {
            if (listHead == null) {
                Console.WriteLine("The list is empty.");
                return;
            }
            while (listHead != null) {
                Student currentStudent = listHead.GetValue();
                double sum = 0;
                Node<Course> listOfCourses = currentStudent.GetListOfCourses();
                int listLength = NumberOfNodes(listOfCourses);
                if (listLength > 0) {
                    for (int i = 0; i < listLength; i++) {
                        sum += listOfCourses.GetValue().GetCourseGrade();
                        listOfCourses = listOfCourses.GetNext();
                    }
                    double average = sum / listLength;
                    Console.WriteLine($"Student:{currentStudent.GetName()}, Average grade:{average}");
                }
                else {
                    Console.WriteLine($"Student:{currentStudent.GetName()} has no courses.");
                }
                listHead = listHead.GetNext();
            }
        } // Print average grade for each student in the student list #24
        public static Node<Student> ReturnExcellentStudents(Node<Student[]> listHead) {
            if (listHead == null)
                return null;
            Node<Student> newList = null;
            while (listHead != null) {
                int index = 0;
                double bestGrade = double.MinValue;
                for (int i = 0; i < listHead.GetValue().Length; i++) {
                    double studentAverageGrade = FindAverageGrade(listHead.GetValue()[i]);
                    if (studentAverageGrade > bestGrade) {
                        index = i;
                        bestGrade = studentAverageGrade;
                    }
                }
                newList = AddLast(newList, listHead.GetValue()[index]);
                listHead = listHead.GetNext();
            }
            return newList;
        } // Return excellenting student in each class #25
        public static double FindAverageGrade(Student student) {
            double sum = 0;
            Node<Course> studentCourses = student.GetListOfCourses();
            if (studentCourses == null)
                return -1;
            int amountOfCourses = NumberOfNodes(studentCourses);
            while (studentCourses != null) {
                sum += studentCourses.GetValue().GetCourseGrade();
                studentCourses = studentCourses.GetNext();
            }
            return sum / amountOfCourses;
        }
        public static Node<Student> ReturnGraduatingStudents(Node<Student>[] classesArray) {
            if (classesArray == null) return null;
            Node<Student> passingList = null;
            int passingGrade = 55;
            for (int i = 0; i < classesArray.Length; i++) {
                Node<Student> currentStudentList = classesArray[i];
                while (currentStudentList != null) {
                    Student student = currentStudentList.GetValue();
                    int succeeded = 0;
                    int failed = 0;
                    Node<Course> courses = student.GetListOfCourses();
                    while (courses != null) {
                        if (courses.GetValue().GetCourseGrade() >= passingGrade)
                            succeeded++;
                        else
                            failed++;
                        courses = courses.GetNext();
                    }
                    if (succeeded > failed) {
                        passingList = AddLast(passingList, student);
                    }
                    currentStudentList = currentStudentList.GetNext();
                }
            }
            return passingList;
        } // return passing students #26
        public static BinNode<T> GetLastBinNodeNode<T>(BinNode<T> listHead) {
            if (listHead == null) return null;
            while (listHead.HasRight())
                listHead = listHead.GetRight();
            return listHead;
        } // Get last node in a BinNode list helpful for #Q27
        public static bool IsPalindrome<T>(BinNode<T> listHead) {
            if (listHead == null || !listHead.HasRight()) return true;

            BinNode<T> lastNode = GetLastBinNodeNode<T>(listHead);
            while (listHead != lastNode && listHead.GetLeft() != lastNode) {
                if (!listHead.GetValue().Equals(lastNode.GetValue()))
                    return false;
                listHead = listHead.GetRight();
                lastNode = lastNode.GetLeft();
            }
            return true;
        } // Check if BinNode list is a Palindrome #27

        //TEST FUNCTIONS:
        public static void RunWorkerTests() {
            Console.Clear();
            Console.WriteLine("=== WORKER TESTS ===");
            Worker alice = new Worker("Alice", 5000);
            Worker bob = new Worker("Bob", 3000);
            Worker charlie = new Worker("Charlie", 5000);

            Node<Worker> wList = new Node<Worker>(alice);
            AddLast(wList, bob);
            AddLast(wList, charlie);

            Console.WriteLine($"Original: {wList}");
            Console.WriteLine($"Sorted:   {SortList(wList)}");
        }
        public static void RunStudentTests() {
            Console.Clear();
            Console.WriteLine("=== STUDENT TESTS (Q24-Q26) ===");

            Student s1 = new Student("Avi", new Node<Course>(new Course("Math", 90)));
            Student s2 = new Student("Dana", new Node<Course>(new Course("Math", 40)));

            Node<Course> c3 = new Node<Course>(new Course("Bio", 100));
            AddLast(c3, new Course("Chem", 80));
            AddLast(c3, new Course("Physics", 30));
            Student s3 = new Student("Noam", c3);

            // 2. Test Q25 (Excellence)
            Node<Student> classA = new Node<Student>(s1);
            AddLast(classA, s2);
            Node<Student> classB = new Node<Student>(s3);

            Node<Student[]> schoolList = new Node<Student[]>(new Student[] { s1, s2 });
            AddLast(schoolList, new Student[] { s3 });

            Console.WriteLine("Running Excellence Check (Q25)...");
            Console.WriteLine(ReturnExcellentStudents(schoolList));

            // 3. Test Q26 (Graduation)
            Console.WriteLine("\nRunning Graduation Check (Q26)...");
            Node<Student>[] schoolArray = new Node<Student>[2];
            schoolArray[0] = classA;
            schoolArray[1] = classB;

            Console.WriteLine(ReturnGraduatingStudents(schoolArray));
        }
        public static void RunPalindromeTest() {
            Console.Clear();
            Console.WriteLine("=== PALINDROME TEST (Q27) ===");

            // Create "LEVEL"
            BinNode<char> l1 = new BinNode<char>('L');
            BinNode<char> e1 = new BinNode<char>('E');
            BinNode<char> v1 = new BinNode<char>('V');
            BinNode<char> e2 = new BinNode<char>('E');
            BinNode<char> l2 = new BinNode<char>('L');

            l1.SetRight(e1); e1.SetLeft(l1);
            e1.SetRight(v1); v1.SetLeft(e1);
            v1.SetRight(e2); e2.SetLeft(v1);
            e2.SetRight(l2); l2.SetLeft(e2);

            Console.WriteLine($"Testing 'LEVEL': {IsPalindrome(l1)}");

            // Create "ABC"
            BinNode<char> a = new BinNode<char>('A');
            BinNode<char> b = new BinNode<char>('B');
            BinNode<char> c = new BinNode<char>('C');
            a.SetRight(b); b.SetLeft(a);
            b.SetRight(c); c.SetLeft(b);

            Console.WriteLine($"Testing 'ABC':   {IsPalindrome(a)}");
        }
        public static void Menu() {
            Node<int> myList = new Node<int>(10);
            AddLast(myList, 20);
            AddLast(myList, 5);
            AddLast(myList, 30);

            bool running = true;
            while (running) {
                Console.Clear();
                Console.WriteLine($"CURRENT LIST: {myList}");
                Console.WriteLine("========================================");
                Console.WriteLine("          DATA STRUCTURES MENU          ");
                Console.WriteLine("========================================");
                Console.WriteLine("--- Basic Operations ---");
                Console.WriteLine("1.  Add First");
                Console.WriteLine("2.  Add Last");
                Console.WriteLine("3.  Delete First");
                Console.WriteLine("4.  Delete Last");
                Console.WriteLine("5.  Count Nodes");
                Console.WriteLine("6.  Find Value (Contains)");
                Console.WriteLine("7.  Get Value by Index");

                Console.WriteLine("\n--- Advanced Algorithms ---");
                Console.WriteLine("8.  Reverse List");
                Console.WriteLine("9.  Sort List");
                Console.WriteLine("10. Remove Duplicates");

                Console.WriteLine("\n--- Scenario Tests ---");
                Console.WriteLine("11. Run Worker Class Tests");
                Console.WriteLine("12. Run Student/School Tests (Q24-Q26)");
                Console.WriteLine("13. Run Palindrome Test (Q27)");

                Console.WriteLine("\n--- MASTER TEST ---");
                Console.WriteLine("14. Run ALL Tests");

                Console.WriteLine("0.  Exit");
                Console.WriteLine("========================================");
                Console.Write("Enter choice: ");

                string input = Console.ReadLine();

                switch (input) {
                    case "1":
                        Console.Write("Enter number to add: ");
                        int val1 = int.Parse(Console.ReadLine());
                        myList = AddFirst(myList, val1);
                        Console.WriteLine($"\n[Success] Added {val1}. Press any key...");
                        Console.ReadKey();
                        break;

                    case "2":
                        Console.Write("Enter number to add: ");
                        int val2 = int.Parse(Console.ReadLine());
                        myList = AddLast(myList, val2);
                        Console.WriteLine($"\n[Success] Added {val2}. Press any key...");
                        Console.ReadKey();
                        break;

                    case "3":
                        myList = DeleteFirst(myList);
                        Console.WriteLine("\n[Success] First item deleted. Press any key...");
                        Console.ReadKey();
                        break;

                    case "4":
                        myList = DeleteLast(myList);
                        Console.WriteLine("\n[Success] Last item deleted. Press any key...");
                        Console.ReadKey();
                        break;

                    case "5":
                        Console.WriteLine($"\n[Result] Total Nodes: {NumberOfNodes(myList)}");
                        Console.WriteLine("Press any key...");
                        Console.ReadKey();
                        break;

                    case "6":
                        Console.Write("Enter number to find: ");
                        int searchVal = int.Parse(Console.ReadLine());
                        bool found = ContainsNode(myList, searchVal);
                        if (found)
                            Console.WriteLine("\n[Result] Found it!");
                        else
                            Console.WriteLine("[Result] Not found.");
                        Console.WriteLine("Press any key...");
                        Console.ReadKey();
                        break;

                    case "7":
                        Console.Write("Enter index: ");
                        int idx = int.Parse(Console.ReadLine());
                        Node<int> resNode = ReturnNodeByIndex(myList, idx);
                        if (resNode != null)
                            Console.WriteLine($"\n[Result] Value at index {idx}: {resNode.GetValue()}");
                        else
                            Console.WriteLine("\n[Error] Index out of range.");
                        Console.WriteLine("Press any key...");
                        Console.ReadKey();
                        break;

                    case "8":
                        myList = ReverseList(myList);
                        Console.WriteLine("\n[Success] List Reversed. Press any key...");
                        Console.ReadKey();
                        break;

                    case "9":
                        myList = SortList(myList);
                        Console.WriteLine("\n[Success] List Sorted. Press any key...");
                        Console.ReadKey();
                        break;

                    case "10":
                        myList = DeleteDupes(myList);
                        Console.WriteLine("\n[Success] Duplicates Removed. Press any key...");
                        Console.ReadKey();
                        break;

                    case "11":
                        RunWorkerTests();
                        Console.ReadKey();
                        break;

                    case "12":
                        RunStudentTests();
                        Console.ReadKey();
                        break;

                    case "13":
                        RunPalindromeTest();
                        Console.ReadKey();
                        break;

                    case "14":
                        RunTests();
                        Console.WriteLine("\n[Success] All tests finished. Press any key to return...");
                        Console.ReadKey();
                        break;

                    case "0":
                        running = false;
                        break;

                    default:
                        Console.WriteLine("\nInvalid option. Press any key...");
                        Console.ReadKey();
                        break;
                }
            }

        }
    }
}






