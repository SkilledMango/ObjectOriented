﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NodeProject
{
    internal class Worker : IComparable<Worker>
    {
        string name;
        double salary;
        public Worker(string name, double salary) {
            this.name = name;
            this.salary = salary;
        }
        public void SetName(string name) {
            this.name = name;
        }
        public string GetName() {
            return this.name;
        }
        public double GetSalary() {
            return this.salary;
        }
        public void SetSalary(double salary) {
            this.salary = salary;
        }
        public int CompareTo(Worker other) {
            if (other == null) return 1;
            return this.salary.CompareTo(other.salary);
        }
        public override bool Equals(object obj) {
            if (obj is Worker other)
                return this.name == other.name && this.salary == other.salary;
            return false;
        }
        public override string ToString() {
            return $"Name:{name}, Salary:{salary} ";
        }
    }
}
