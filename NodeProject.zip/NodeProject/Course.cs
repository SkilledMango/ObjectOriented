﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NodeProject
{
    internal class Course : IComparable<Course>
    {
        string courseCode;
        double courseGrade;
        public Course(string courseCode, double courseGrade) {
            this.courseCode = courseCode;
            this.courseGrade = courseGrade;
        }
        public int CompareTo(Course other) {
            if (other == null) return 1;
            return this.courseGrade.CompareTo(other.courseGrade);
        }
        public override bool Equals(object obj) {
            if (obj is Course other)
                return this.courseCode == other.courseCode && this.courseGrade == other.courseGrade;
            return false;
        }
        public void SetCourseCode(string courseCode) {
            this.courseCode = courseCode;
        }
        public string GetCourseCode() {
            return this.courseCode;
        }
        public double GetCourseGrade() {
            return this.courseGrade;
        }
        public void SetCourseGrade(double courseGrade) {
            this.courseGrade = courseGrade;
        }
        public override string ToString() {
            return $"Course code:{courseCode}, Course grade:{courseGrade}";
        }
    }
}
