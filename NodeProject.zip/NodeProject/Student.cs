﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NodeProject
{
    internal class Student : IComparable<Student>
    {
        string name;
        Node<Course> listOfCourses;
        public Student(string name, Node<Course> listOfCourses) {
            this.name = name;
            this.listOfCourses = listOfCourses;
        }

        public void SetName(string name) {
            this.name = name;
        }
        public string GetName() {
            return this.name;
        }
        public void SetListOfCourses(Node<Course> listOfCourses) {
            this.listOfCourses = listOfCourses;
        }
        public Node<Course> GetListOfCourses() {
            return this.listOfCourses;
        }
        public override string ToString() {
            return $"Name:{name}, Courses:{listOfCourses}";
        }
        public int CompareTo(Student other) {
            if (other == null) return 1;
            return this.name.CompareTo(other.name);
        }

    }
}
